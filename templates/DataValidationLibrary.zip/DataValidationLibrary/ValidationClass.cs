﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataValidationLibrary
{
    static public class ValidationClass
    {
        static public int num;

        static public bool IsInteger(string textIn, string name)
        {
            //int num;

            if (int.TryParse(textIn, out num) == true)
                return true;
            else
            {
                Console.WriteLine("{0} must be of type integer", name);

                return false;
            }


        }



        static public bool IsDouble(string textIn, string name)
        {
            double num;

            if (double.TryParse(textIn, out num) == true)
                return true;
            else
            {
                Console.WriteLine("{0} must be of type double ", name);

                return false;
            }


        }


        static public bool IsPresent(string textIn, string name)
        {
            if (textIn == "")
            {
                Console.WriteLine("{0} must be present", name);
                return false;
            }
            else
                return true;

        }


        static public bool IsWithInRange(string textIn, string name, int min, int max)

        {
            int number = int.Parse(textIn);
            if (number < min || number > max)
            {
                Console.WriteLine("{0} must be within range {1} and{2}", name, min, max);
                return false;
            }
            else
                return true;

        }

        static public bool StartChar(string textIn, string name, string startPattern)

        {

            if (textIn.StartsWith(startPattern) == true)
            {
                return true;
            }
            else
            {
                Console.WriteLine("{0} must be start with with {1}", name, startPattern);
                return false;
            }



        }


        static public bool CheckLength(string textIn, string name, int requiredLength)

        {

            if (textIn.Length == requiredLength)
            {
                return true;
            }
            else
            {
                Console.WriteLine("{0} must be {1} characters long", name, requiredLength);
                return false;
            }
        }

    }
}
    